<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\Request;
use App\Http\Requests\Auth\RegisterRequest;

class RegisterController extends Controller
{

    use RegistersUsers;

    public function __construct()
    {

    }

    protected function register(RegisterRequest $request)
    {
       // $serializedArr = serialize($request['phone']);
         User::create([
            'name' => $request['name'],
            'email' => $request['email'],
            'phone' =>  $request['phone'],
        ]);

        return redirect()->route('list');

    }

    public function checkemail(Request $request)
    {
        $email =$request->input('email');
        $user = User::where('email',$email)->first();
        if($user) return response()->json(true);
        else return response()->json(false);

    }
}
